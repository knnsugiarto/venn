# Welcome to your Lovable project

This project was built with [Lovable](https://lovable.dev).

## Build with Lovable

Open your project in the [Lovable editor](https://lovable.dev) and keep building.

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: connect the project to GitHub and every change made in Lovable is committed straight to your repository.
- **Full ownership**: this code is yours. Push to your repository and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```

## Built with

- TanStack Start
- TypeScript
- React
- Tailwind CSS

## Your Circle
Answers build up a profile saved only in this phone's localStorage (`venn.profile.v1`). It is ready with a first name, at least 1 written answer and at least 5 answers in total. Scanning: a ready circle goes straight to the Venn, a partly filled one answers only the missing questions ("Almost there"), and an empty one gets the 5-question quick start. There is still no database: the QR link carries a fresh snapshot (up to 6 most recent written answers plus all taps). Full brief: `docs/ADDON-your-circle.md`.

## Smarter reading (Parts 1, 2, 3 and 5 only)
The landing is reduced to Venn, Start and Privacy; returning users see their code and a plain theme list. Each existing prompt has its own placeholder, never submitted as an answer. Matching interprets cited answers first, checks hidden evidence and readings, then checks natural-writing style. Fact failures block results; style-only failures get one retry and choose the fact-safe reply with fewer issues. Demo output uses the same guard and is labelled **Demo mode · not Claude**. No tap, readiness or QR-format changes from Parts 4/6 are included.

Run `bunx vitest run` for the checks. `bun eval/run-context.ts` runs the ten context pairs three times and emits a TSV for human gloss/tone review, plus automated kind, guard, style-code and latency metrics. It requires the existing `ANTHROPIC_API_KEY`; it does not switch providers or models when unavailable. Current live-evaluation gaps are recorded in `docs/DECISIONS.md`. Branch/deploy instructions map to the **Smarter reading** Lovable draft; accepting and publishing remain user actions.
